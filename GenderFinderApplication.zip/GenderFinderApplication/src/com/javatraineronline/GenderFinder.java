package com.javatraineronline;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import com.google.gson.Gson;

public class GenderFinder {

	// Service URL
	private static final String SERVICE_URL = "https://gender-api.com/get?";
	
	// Your Secret Key provided by Service Provider
	private static final String SECRET_KEY = "pyXMQrpqTTjdMGJUXA";
	
	public static Result getGenderType(String name) {
		
		Result result = null;
		
		// Gson API for JSON to Object Conversion in Java
		Gson gson = new Gson();
		
		if(name != null && !name.isEmpty()) {
			
			try {
				
				// Preparing Request URL
				final String requestURL = SERVICE_URL + "name="+name + "&key="+ SECRET_KEY;
				
				URL url = new URL(requestURL);
				
				HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
				
				// Getting the InputStream from URL
				InputStream inputStream =  httpURLConnection.getInputStream();
				
				String response = "";
				
				// Reading the Response
				if(inputStream != null) {
					
					int data = inputStream.read();
					
					while(data != -1) {
						
						response = response + (char)data;
						
						data = inputStream.read();
					}
				}
				
				// Closing the Resource
				inputStream.close();
				
				System.out.println("Response from (Gender-API Service) :  "+response);
				
				// Converting JSON to Result Object
				result = gson.fromJson(response, Result.class);
				
			} catch (MalformedURLException e) {
				
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (IOException e) {
				
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the name to find gender : ");
		
		String name = scanner.next();
		
		Result result = getGenderType(name);
		
		if(result != null) {
			
			System.out.println("----------------------------");
			System.out.println("The "+result.getName()+" is a "+result.getGender());
		} else {
			
			System.out.println("No response from service...");
		}

		scanner.close();
		
	}

}
