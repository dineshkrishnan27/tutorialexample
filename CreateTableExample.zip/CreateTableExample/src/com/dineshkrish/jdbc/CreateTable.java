package com.dineshkrish.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class CreateTable {
	
	public static boolean doTableCreation(final String query) {
		
		Connection connection = ConnectionProvider.getConnection();
		
		if(query == null || query.isEmpty()) {
			
			return false;
		}

		try {

			Statement statement = connection.createStatement();

			statement.execute(query);
			
			connection.close();
			
			return true;
			
		} catch (SQLException e) {

			System.out.println(e.getMessage());
			e.printStackTrace();
			
		} 	
		
		return false;
	}
	

	public static void main(String[] args) {

		final String QUERY = "CREATE TABLE customer ("
				+ "customerId INT, "
				+ "customerName VARCHAR(30), "
				+ "customerAge INT, "
				+ "customerAddress VARCHAR(60), "
				+ "PRIMARY KEY(customerId))";

		boolean flag = CreateTable.doTableCreation(QUERY);
		
		if(flag) {
			
			System.out.println("Table has been Created Successfully...");
			
		} else {
			
			System.out.println("Application Error Occurred...");
		}

	}
}
