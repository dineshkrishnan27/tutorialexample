package com.dineshkrish.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {

	public static Connection connection;
	
	private static final String DRIVERNAME = "com.mysql.jdbc.Driver"; // Database driver name
	private static final String CONNECTION_URL = "jdbc:mysql://localhost:3306/"; // Connection URL 
	private static final String DATABASE_NAME = "dineshkrish"; // Database Name
	private static final String DATABASE_USERNAME = "root"; // Database User name
	private static final String DATABASE_PASSWORD = ""; // Database Password
	
	public static Connection getConnection() {
		
		try {
			
			// Loading the JDBC Driver for Specific Database
			Class.forName(DRIVERNAME);
			
			System.out.println("Loaded");
			
			// Getting the Connection by passing Connection URL, User name and Password
			connection = DriverManager.getConnection(CONNECTION_URL + DATABASE_NAME, DATABASE_USERNAME, DATABASE_PASSWORD);
			
			System.out.println("Connected");
			
		} catch (ClassNotFoundException ex) {
			
			// Do Something here...
			
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			
		} catch (SQLException ex) {
			
			// Do Something here...
			
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		
		return connection;
	}
}
