package com.dineshkrish.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class RecordInsert {

	public static boolean doInsert(int customerId, String customerName,
			int customerAge, String customerAddress) {

		Connection connection = null;
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dineshkrish", "root", "");

			boolean flag = doValidate(customerId, customerName, customerAge, customerAddress);
			
			if(!flag) {
				
				return false;
			}
			
			final String INSERT_QUERY = "insert into customer (customerId, customerName, customerAge, customerAddress) values("
					+ customerId
					+ ", '"
					+ customerName
					+ "', "
					+ customerAge
					+ ", '" + customerAddress + "')";
			
			Statement statement = connection.createStatement();
			
			statement.execute(INSERT_QUERY);
			
			return true;
			
		} catch (SQLException e) {
			
			System.out.println(e.getMessage());
			e.printStackTrace();
			
		} catch (ClassNotFoundException e) {
			
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		
		return false;
	}
	
	public static boolean doValidate(int customerId, String customerName,
			int customerAge, String customerAddress) {
		
		if(customerId <= 0) {
			
			return false;
		}
		
		if(customerName == null || customerName.isEmpty()) {
			
			return false;
		}
		
		if(customerAge <= 0) {
			
			return false;
		}
		
		if(customerAddress == null || customerAddress.isEmpty()) {
			
			return false;
		}
		
		return true;
	}

	public static void main(String[] args) {

		
		boolean status = doInsert(101, "Dinesh Krishnan", 26, "India");
		
		if(status) {
			
			System.out.println("Record Inserted");
		} else {
			
			System.out.println("Application Error Occured");
		}
		
	}

}
